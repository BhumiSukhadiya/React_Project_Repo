import { combineReducers } from 'redux';
import counter from './test_route/Test_route.reducer';
import authentication from './login/Login.reducer';

export default combineReducers({
    counter,
    authentication
});
