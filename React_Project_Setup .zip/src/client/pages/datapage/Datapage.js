import React, {Component, PropTypes} from "react";
import {connect} from "react-redux";
// Import Style

class Datapage extends Component {
    render() {
        return (
            <div>datapage</div>
        );
    }
}

const mapStateToProps = (state) => {
    return {};
};

const mapDispatchToProps = (dispatch) => {
    return {};
};

Datapage.propTypes = {};

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(Datapage);
