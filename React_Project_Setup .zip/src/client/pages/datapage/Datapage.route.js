import React from 'react';
import Layout from '../../components/Layout';
import DataPage from './Datapage';

const title = 'Datapage';

export default {
    path: '/datapage',
    action() {
        return {
            title,
            component: <Layout><DataPage title={title} /></Layout>,
        };
    },
};