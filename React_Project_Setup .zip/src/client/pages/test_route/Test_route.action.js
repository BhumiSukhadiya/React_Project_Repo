import {INC_COUNTER,TEST_DATA} from '../../constants'
export function incCounter() {
    localStorage.setItem('test','hiii')
  return{
    type:INC_COUNTER
  }
}


