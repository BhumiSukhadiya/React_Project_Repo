// Import Actions
import {  } from './UserActions';

// Initial State
const initialState = {};

const UserReducer = (state = initialState, action) => {
  switch (action.type) {
    default:
      return state;
  }
};

export default UserReducer;
