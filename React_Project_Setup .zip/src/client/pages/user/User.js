import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

// Import Style
import styles from './User.css';

class User extends Component {
  render() {
    return (
        <div>User</div>
    );
  }
}

const mapStateToProps = (state) => {
  return {};
};

const mapDispatchToProps = (dispatch) => {
  return {};
};

User.propTypes = {
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(User);
