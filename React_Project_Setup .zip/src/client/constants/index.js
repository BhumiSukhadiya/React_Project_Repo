/* eslint-disable import/prefer-default-export */

export const SET_RUNTIME_VARIABLE = 'SET_RUNTIME_VARIABLE';
export const INC_COUNTER = 'INC_COUNTER';
export const SET_TOKEN = 'SET_TOKEN';
