import { Router } from 'express';
import * as TestfinalController from './testfinal.controller';

const router = new Router();


export default router;
