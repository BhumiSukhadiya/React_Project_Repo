import mongoose from 'mongoose';
const Schema = mongoose.Schema;

const testfinalSchema = new Schema({

});

export default mongoose.model('Testfinal', testfinalSchema);
